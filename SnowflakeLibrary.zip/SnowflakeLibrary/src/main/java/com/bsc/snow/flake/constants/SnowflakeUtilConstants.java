package com.bsc.snow.flake.constants;


/**
 * 
 * @author Manimaran
 * @version 1.0
 *
 */
public class SnowflakeUtilConstants {

	public static final String TEXT = "TEXT";
	public static final String TIMEOUT="60";
	public static final String CONTENT_TYPE ="Content-Type";
	public static final String APPLICATION_JSON="application/json";
	public static final String AUTHORIZATION="Authorization";
	public static final String AUTHORIZATION_TYPE="X-Snowflake-Authorization-Token-Type";
	public static final String KEYPAIR_JWT="KEYPAIR_JWT";
	public static final String ACCEPT_HEADER="Accept";
	public static final String USER_AGENT_HEADER="User-Agent";
	public static final String USER_AGENT_VALUE="SnowflakeUtil/1.0.0";
	public static final String BEARER = "Bearer ";
	
}
