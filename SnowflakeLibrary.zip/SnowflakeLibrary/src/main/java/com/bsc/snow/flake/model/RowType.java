package com.bsc.snow.flake.model;

public class RowType {

	private String name;
	private String database;
	private String schema;
	private String table;
	private boolean nullable;
	private long byteLength;
	private Object scale;
	private Object collation;
	private Object precision;
	private String type;
	private long length;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDatabase() {
		return database;
	}
	public void setDatabase(String database) {
		this.database = database;
	}
	public String getSchema() {
		return schema;
	}
	public void setSchema(String schema) {
		this.schema = schema;
	}
	public String getTable() {
		return table;
	}
	public void setTable(String table) {
		this.table = table;
	}
	public boolean isNullable() {
		return nullable;
	}
	public void setNullable(boolean nullable) {
		this.nullable = nullable;
	}
	public long getByteLength() {
		return byteLength;
	}
	public void setByteLength(long byteLength) {
		this.byteLength = byteLength;
	}
	public Object getScale() {
		return scale;
	}
	public void setScale(Object scale) {
		this.scale = scale;
	}
	public Object getCollation() {
		return collation;
	}
	public void setCollation(Object collation) {
		this.collation = collation;
	}
	public Object getPrecision() {
		return precision;
	}
	public void setPrecision(Object precision) {
		this.precision = precision;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public long getLength() {
		return length;
	}
	public void setLength(long length) {
		this.length = length;
	}
	@Override
	public String toString() {
		return "RowType [name=" + name + ", database=" + database + ", schema=" + schema + ", table=" + table
				+ ", nullable=" + nullable + ", byteLength=" + byteLength + ", scale=" + scale + ", collation="
				+ collation + ", precision=" + precision + ", type=" + type + ", length=" + length + "]";
	}
	
	
	
}
