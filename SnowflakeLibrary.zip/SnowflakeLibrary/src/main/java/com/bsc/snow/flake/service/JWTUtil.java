package com.bsc.snow.flake.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;

/**
 * <HTML>This class Generate the JWT Token</HTML>
 * 
 * @author Manimaran
 * @version 1.0
 *
 */
public class JWTUtil {
	
	@Value("snowflake.account.identifier")
	private String accountIdentifier;
	
	@Value("snowflake.account.user")
	private String accountUser;
	
	@Value("snowflake.public.key.path")
	private String publicKeyPath;
	
	@Value("snowflake.private.key.path")
	private String privateKeyPath;
	
	private static final Logger LOGGER = LogManager.getLogger(JWTUtil.class);

	public String getJWTToken() {
		String token = null;
		try {

		    RSAPublicKey rsaPublicKey = getPublicKey(publicKeyPath);
			RSAPrivateKey rsaPrivateKey = getPrivateKey(privateKeyPath);
			Algorithm algorithm = Algorithm.RSA256(rsaPublicKey, rsaPrivateKey);
			Calendar cal = Calendar.getInstance();
			cal.setTimeZone(TimeZone.getTimeZone("UTC"));
			Date issuedTime = cal.getTime();
			cal.add(Calendar.HOUR, 1);
			Date expiryTime = cal.getTime();
			String publicKeyFingerPrint = getPublicKeyFingerPrint(rsaPublicKey);
			token = JWT.create()
		        .withIssuer(accountIdentifier + "." + accountUser + "." + publicKeyFingerPrint)
		        .withSubject(accountIdentifier + "." + accountUser)
		        .withIssuedAt(issuedTime)
		        .withExpiresAt(expiryTime)
		        .sign(algorithm);
		} catch (JWTCreationException e){
			LOGGER.error(e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		} catch (GeneralSecurityException e) {
			LOGGER.error(e.getMessage());
		}
		
		return token;
	}
	
	private String getPublicKeyFingerPrint(RSAPublicKey rsaPublicKey) {
		String output ="";
		MessageDigest digest = null;
		try {
			digest = MessageDigest.getInstance("SHA-256");
			byte[] result = digest.digest(rsaPublicKey.getEncoded());
			output= Base64.getEncoder().encodeToString(result);
			output = "SHA256:"+output;
		} catch (NoSuchAlgorithmException e) {
			LOGGER.error(e.getMessage());
		}
		return output;
	}

	public RSAPrivateKey getPrivateKey(String filename) throws IOException, GeneralSecurityException {
	    String privateKeyPEM = getKey(filename);
	    return getPrivateKeyFromString(privateKeyPEM);
	}

	public RSAPrivateKey getPrivateKeyFromString(String key) throws IOException, GeneralSecurityException {
	    String privateKeyPEM = key;
	    privateKeyPEM = privateKeyPEM.replace("-----BEGIN PRIVATE KEY-----\n", "");
	    privateKeyPEM = privateKeyPEM.replace("-----END PRIVATE KEY-----", "");
	    privateKeyPEM = privateKeyPEM.replace("\n", "");
	    byte[] encoded = Base64.getDecoder().decode(privateKeyPEM);
	    KeyFactory kf = KeyFactory.getInstance("RSA");
	    PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
	    RSAPrivateKey privKey = (RSAPrivateKey) kf.generatePrivate(keySpec);
	    return privKey;
	}


	public RSAPublicKey getPublicKey(String filename) throws IOException, GeneralSecurityException {
	    String publicKeyPEM = getKey(filename);
	    return getPublicKeyFromString(publicKeyPEM);
	}

	public RSAPublicKey getPublicKeyFromString(String key) throws IOException, GeneralSecurityException {
	    String publicKeyPEM = key;
	    publicKeyPEM = publicKeyPEM.replace("-----BEGIN PUBLIC KEY-----\n", "");
	    publicKeyPEM = publicKeyPEM.replace("-----END PUBLIC KEY-----", "");
	    publicKeyPEM = publicKeyPEM.replace("\n","");
	    byte[] encoded = Base64.getDecoder().decode(publicKeyPEM);
	    KeyFactory kf = KeyFactory.getInstance("RSA");
	    RSAPublicKey pubKey = (RSAPublicKey) kf.generatePublic(new X509EncodedKeySpec(encoded));
	    return pubKey;
	}
	private String getKey(String filename) throws IOException {
	    // Read key from file
	    String strKeyPEM = "";
	    BufferedReader br = new BufferedReader(new FileReader(filename));
	    String line;
	    while ((line = br.readLine()) != null) {
	        strKeyPEM += line + "\n";
	    }
	    br.close();
	    return strKeyPEM;
	}

}
