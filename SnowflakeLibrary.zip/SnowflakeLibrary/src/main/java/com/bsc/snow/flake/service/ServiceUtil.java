package com.bsc.snow.flake.service;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;

import com.bsc.snow.flake.constants.SnowflakeUtilConstants;
import com.bsc.snow.flake.model.Binding;
import com.bsc.snow.flake.model.Request;
/**
 * <HTML>This is a utility class which builds request for Snowflake API</HTML>
 * 
 * @author Manimaran
 * @version 1.0
 *
 */
public class ServiceUtil {
	
	private static final Logger LOGGER = LogManager.getLogger(ServiceUtil.class);
	
	public Request createRequest(String query, LinkedHashMap<String, String> parameters) {
		Request request = new Request();
		
		Map<String, Binding> bindings = null;
		
		try {
			if(parameters!=null && !parameters.isEmpty()) {
				bindings = generateBindings(parameters);
			}
			
			request.setStatement(query);
			request.setTimeout(SnowflakeUtilConstants.TIMEOUT);
			request.setDatabase("");
			request.setSchema("");
			request.setRole("");
			request.setWarehouse("");
			request.setBindings(bindings);
		}catch(Exception e) {
			LOGGER.error(e.getMessage());
		}
		
		return request;
	}

	private Map<String, Binding> generateBindings(Map<String, String> parameters) {
		Map<String, Binding> bindings = new LinkedHashMap<String, Binding>();
		
		for( Entry<String,String> entry  : parameters.entrySet()) {
			Binding b = new Binding(SnowflakeUtilConstants.TEXT, entry.getValue());
			bindings.put(entry.getKey(),b);
		}
		
		return bindings;
	}

	public HttpHeaders getHeaders(String jwtToken) {
		HttpHeaders headers = new HttpHeaders();
		headers.add(SnowflakeUtilConstants.CONTENT_TYPE, SnowflakeUtilConstants.APPLICATION_JSON);
		headers.add(SnowflakeUtilConstants.AUTHORIZATION, SnowflakeUtilConstants.BEARER + jwtToken);
		headers.add(SnowflakeUtilConstants.AUTHORIZATION_TYPE, SnowflakeUtilConstants.KEYPAIR_JWT);
		headers.add(SnowflakeUtilConstants.ACCEPT_HEADER, SnowflakeUtilConstants.APPLICATION_JSON);
		headers.add(SnowflakeUtilConstants.USER_AGENT_HEADER, SnowflakeUtilConstants.USER_AGENT_VALUE);
		return headers;
	}
}
