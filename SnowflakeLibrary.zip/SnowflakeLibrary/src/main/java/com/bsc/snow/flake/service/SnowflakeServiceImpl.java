package com.bsc.snow.flake.service;

import java.util.LinkedHashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.snow.flake.model.Request;
import com.bsc.snow.flake.model.Response;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <HTML>This class will interact with the Snowflake REST API</HTML>
 * 
 * @author Manimaran
 * @version 1.0
 *
 */

@Component
public class SnowflakeServiceImpl{
	
	@Value("${snowflake.url}")
	private String snowFlakeURL;

	private RestTemplate rest = new RestTemplate();
	
	private static final Logger LOGGER = LogManager.getLogger(SnowflakeServiceImpl.class);

	private ServiceUtil serviceUtil;
	
	private JWTUtil jwtUtil;
	
	public SnowflakeServiceImpl() {
		this.jwtUtil = new JWTUtil();
		this.serviceUtil = new ServiceUtil();
	}
	
	public Response query(String query, LinkedHashMap<String,String> parameters) {

		Request request = serviceUtil.createRequest(query,parameters);
		
		Response res = new Response();
		
		HttpHeaders headers = serviceUtil.getHeaders(jwtUtil.getJWTToken());
		
		HttpEntity<Request> requestEntity = new HttpEntity<Request>(request,headers);
		
		LOGGER.debug("Snowflake REST call : {}", snowFlakeURL);
		
		ResponseEntity<String> responseEntity = rest.exchange(snowFlakeURL, HttpMethod.POST, requestEntity, String.class);
		
		LOGGER.debug("Snowflake REST call Response : {}",responseEntity.getStatusCode());

		ObjectMapper mapper = new ObjectMapper();
		
		try {
			res = mapper.readValue(responseEntity.getBody(), Response.class);
		} catch (JsonProcessingException e) {
			LOGGER.error(e.getMessage());
		}
		
		return res;
	}
	
}
