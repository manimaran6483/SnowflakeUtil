package com.bsc.snow.flake.model;

import java.util.List;

public class MetaData {

	private int numRows;
	
	private String format;
	
	private List<PartitionInfo> partitionInfo;
	
	private List<RowType> rowType;

	public int getNumRows() {
		return numRows;
	}

	public void setNumRows(int numRows) {
		this.numRows = numRows;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public List<PartitionInfo> getPartitionInfo() {
		return partitionInfo;
	}

	public void setPartitionInfo(List<PartitionInfo> partitionInfo) {
		this.partitionInfo = partitionInfo;
	}

	public List<RowType> getRowType() {
		return rowType;
	}

	public void setRowType(List<RowType> rowType) {
		this.rowType = rowType;
	}

	@Override
	public String toString() {
		return "MetaData [numRows=" + numRows + ", format=" + format + ", partitionInfo=" + partitionInfo + ", rowType="
				+ rowType + "]";
	}
	
}
