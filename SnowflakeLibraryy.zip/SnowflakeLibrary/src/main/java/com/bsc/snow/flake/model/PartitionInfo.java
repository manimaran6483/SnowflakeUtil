package com.bsc.snow.flake.model;

public class PartitionInfo {

	private int rowCount;
	
	private int uncompressedSize;

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getUncompressedSize() {
		return uncompressedSize;
	}

	public void setUncompressedSize(int uncompressedSize) {
		this.uncompressedSize = uncompressedSize;
	}

	@Override
	public String toString() {
		return "PartitionInfo [rowCount=" + rowCount + ", uncompressedSize=" + uncompressedSize + "]";
	}
	
	
	
}
