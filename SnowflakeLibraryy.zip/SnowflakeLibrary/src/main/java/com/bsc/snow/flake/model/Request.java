package com.bsc.snow.flake.model;

import java.util.Map;

public class Request {

	private String statement;
	private String timeout;
	private String database;
	private String schema;
	private String warehouse;
	private String role;
	private Map<String,Binding> bindings;
	
	public String getStatement() {
		return statement;
	}
	public void setStatement(String statement) {
		this.statement = statement;
	}
	public String getTimeout() {
		return timeout;
	}
	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}
	public String getDatabase() {
		return database;
	}
	public void setDatabase(String database) {
		this.database = database;
	}
	public String getSchema() {
		return schema;
	}
	public void setSchema(String schema) {
		this.schema = schema;
	}
	public String getWarehouse() {
		return warehouse;
	}
	public void setWarehouse(String warehouse) {
		this.warehouse = warehouse;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Map<String,Binding> getBindings() {
		return bindings;
	}
	public void setBindings(Map<String,Binding> bindings) {
		this.bindings = bindings;
	}
	@Override
	public String toString() {
		return "Request [statement=" + statement + ", timeout=" + timeout + ", database=" + database + ", schema="
				+ schema + ", warehouse=" + warehouse + ", role=" + role + ", bindings=" + bindings + "]";
	}
	
	
}
