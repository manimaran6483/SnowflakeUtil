package com.bsc.snow.flake.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Response {

	private MetaData resultSetMetaData;

	private List<List<String>> data;
	
	private String code;
	
	private String statementStatusUrl;
	
	private String requestId;
	
	private String sqlState;
	
	private String statementHandle;
	
	private String message;
	
	private long createdOn;

	public MetaData getResultSetMetaData() {
		return resultSetMetaData;
	}

	public void setResultSetMetaData(MetaData resultSetMetaData) {
		this.resultSetMetaData = resultSetMetaData;
	}

	public List<List<String>> getData() {
		return data;
	}

	public void setData(List<List<String>> data) {
		this.data = data;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStatementStatusUrl() {
		return statementStatusUrl;
	}

	public void setStatementStatusUrl(String statementStatusUrl) {
		this.statementStatusUrl = statementStatusUrl;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getSqlState() {
		return sqlState;
	}

	public void setSqlState(String sqlState) {
		this.sqlState = sqlState;
	}

	public String getStatementHandle() {
		return statementHandle;
	}

	public void setStatementHandle(String statementHandle) {
		this.statementHandle = statementHandle;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public long getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(long createdOn) {
		this.createdOn = createdOn;
	}

	@Override
	public String toString() {
		return "Response [resultSetMetaData=" + resultSetMetaData + ", data=" + data + ", code=" + code
				+ ", statementStatusUrl=" + statementStatusUrl + ", requestId=" + requestId + ", sqlState=" + sqlState
				+ ", statementHandle=" + statementHandle + ", message=" + message + ", createdOn=" + createdOn + "]";
	}
	
	
	
}
